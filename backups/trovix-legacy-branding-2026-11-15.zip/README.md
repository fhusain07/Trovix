# Legacy Trovix branding backup

Contains all 23 assets removed during the branding cleanup: 15 loose logos/icons and the eight-file trovix-new-branding folder. Original filenames and paths are preserved under src/assets/trovix_logo_assets/.

Recovered from Git-stored originals. All eight files from the earlier branding pack match the SHA-256 hashes recorded before deletion; the other 15 are restored from their stored Git blobs. manifest.json lists every asset and its SHA-256 checksum.

Retained for future use. The current website continues to use TROVIX_Campus_Web_Branding_Final. Extract this archive to a separate folder to browse the older assets.
